
#ifndef HELPERS_H
#define HELPERS_H

void printIntArray(int *arr, int size);

#endif // HELPERS_H
